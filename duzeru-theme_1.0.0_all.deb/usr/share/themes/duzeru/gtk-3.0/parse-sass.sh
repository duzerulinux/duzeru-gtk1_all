#! /bin/bash

bundle exec sass --update --style=nested --sourcemap=none .
